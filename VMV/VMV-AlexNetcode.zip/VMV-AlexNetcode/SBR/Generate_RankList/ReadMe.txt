1. Code
   retrieval.m                              ---- Based on the VMV-VGG method, retrieve the rank list by using the generated sketch and model distance matrices
   TestingModelIndexMappingToCLAIndexes.cpp ---- Map the retrieved indexes to the CLA indexes
   concatenateRankedList.m                  ---- Generate the final rank list.
   


      

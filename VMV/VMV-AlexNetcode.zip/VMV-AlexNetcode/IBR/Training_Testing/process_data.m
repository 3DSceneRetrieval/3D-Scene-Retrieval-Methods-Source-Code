kNumClasses = 30;
kNumItems = 390;
kNumFolds = 3;
kNumTrainingItems = ceil(kNumItems * (kNumFolds - 1) / kNumFolds);
kImageWidth = 256;%256 for training, 224 for testing
kNumChannels = 3; 

sets = {'train', 'test', 'val'};
classes = cell(1, kNumClasses);

for i = 1:kNumClasses
    classes{i} = i;
end

meta = struct();
meta.sets = sets;
meta.classes = classes;

labels = ones(1, kNumClasses * kNumItems, 'single');
for i = 1:kNumClasses
    for j = 1:kNumItems
        labels((i - 1) * kNumItems + j) = i;
    end
end

set = ones(1, kNumClasses * kNumItems, 'double');
for i = 1:kNumClasses
    for j = 1:kNumTrainingItems
        set((i - 1) * kNumItems + j) = 1;
    end
    for j = kNumTrainingItems + 1:kNumItems
        set((i - 1) * kNumItems + j) = 3;
    end
end

data = ones(kImageWidth, kImageWidth, kNumChannels, kNumClasses * kNumItems, 'single');
for i = 1:kNumClasses
    i
    for j = 1:kNumItems
        id = (i - 1) * kNumItems + j;
		image_path = strcat('E:\tranining\', int2str(idx), '.png');
        I = imread(image_path);
        [~, ~, dim] = size(I);
         if dim == 1
             I = cat(3, I, I, I);
         end
        data(:, :, :, id) = I;
    end
end

images = struct();
images.labels = labels;
images.set = set;
images.data = data;

imdb = struct();
imdb.images = images;
imdb.meta = meta;


save('SHREC18_extended_30_classes_TrainingImages256.mat', 'images',  'meta', '-v7.3');
%save('SHREC18_extended_30_classes_TestingModels224.mat', 'images',  'meta', '-v7.3');

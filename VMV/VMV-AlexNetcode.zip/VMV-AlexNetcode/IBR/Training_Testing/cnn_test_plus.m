run ('D:\Program Files - Data Drive\matconvnet-1.0-beta16\matlab\vl_setupnn.m');
load('SHREC18_30_classes_TestingModels256.mat');
load('sketch_model_withAugmentation_30Classes256_pretrained\models_trained\net-epoch-600.mat');

testX = 255-imdb.images.data(:,:,:,:);
testY = imdb.images.labels(:,:);
predY = zeros(1,length(testY));

buffer = [];
ptr = 0;
cls = 1;
cnt = 0;
correct = 0;
wrong = 0;
prediction = [];
similarity_list = zeros(0, 6);
distance_matrix = zeros(length(testY), 30);

for i = 1:length(testY)
    i 
    testimg = testX(:,:,:,i);
    im1 = testimg(1:225,1:225,:) ;
    im2 = testimg(32:256,1:225,:) ;
    im3 = testimg(1:225,32:256,:) ;
    im4 = testimg(32:256,32:256,:) ;
    im5 = testimg(16:240,16:240,:) ;
    im15 = cat(4,im1,im2,im3,im4,im5);
    im_new = cat(4,im15,fliplr(im15));
    net.layers{end}.class = kron(ones(1,size(im_new,4)),testY(i));
    res = vl_simplenn(net,im_new,[],[],'disableDropout',true,'conserveMemory',false,'sync',true);
    pred = squeeze(gather(res(end-1).x));
    pred = sum(pred,2);
    distance_matrix(i, :) = pred;
    [~,pred] = max(pred);
    predY(i) = pred;
    ptr = ptr + 1;
    buffer(end + 1) = pred;
    if ptr == 13   %13 1  %each model has 13 faces or each image has 1 face
        ptr = 0;
        pred_class = mode(buffer);
        similarity_list(end + 1, :) = buffer;
        prediction(end + 1) = pred_class;
        if pred_class == cls
            correct = correct + 1;
        else
            wrong = wrong + 1;
        end
        cnt = cnt + 1;
        if cnt == 30   %30 7  %each class has 30 models or 300 images, refer to the .cla files
            cls = cls + 1;
            cnt = 0;
        end
        buffer = [];
    end

end

mean(predY==testY)
disp(correct);
disp(correct / size(prediction, 2));
disp(wrong);
disp(wrong / size(prediction, 2));

%save('distance_matrix_images.mat', 'distance_matrix', '-v7.3');
save('distance_matrix_models.mat', 'distance_matrix', '-v7.3');

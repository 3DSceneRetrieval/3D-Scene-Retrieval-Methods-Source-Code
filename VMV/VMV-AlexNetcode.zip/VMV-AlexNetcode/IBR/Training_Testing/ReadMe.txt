1. Pre-requisite package
   matconvnet-1.0-beta23, refer to: http://www.vlfeat.org/matconvnet/

2. Code
   process_data.m                  ---- Pre-process all the 256x256 training images or 224x224 testing images 
   cnn_sketch.m                    ---- Initialize the CNN model, load and train the pre-processed training data with augmentation
   cnn_test.m                      ---- Load and test the pre-processed testing data, generate the image and model distance matrices


      

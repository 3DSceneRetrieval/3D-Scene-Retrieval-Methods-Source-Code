index=load('9000imagesIndexInClaTest.txt');
for i=1:length(index)
    path1=strcat('RankValueList_mapped/value', int2str(i), '.txt');
    path2=strcat('RankValueList_mapped/', int2str(i), '.txt');

    a=load(path1);
    b=load(path2);

    result=cat(2,a,b);
    path=strcat('FinalResult/', int2str(index(i)));

    fid=fopen(path,'w+');
    for j=1:length(a)
        for k=1:2
            if k==1
              fprintf(fid,'%12.12f  ',result(j,k));  
            else
              fprintf(fid,'%d\r\n',result(j,k));  
              %result(j,k)
            end
        end
    end
    fclose(fid);

end

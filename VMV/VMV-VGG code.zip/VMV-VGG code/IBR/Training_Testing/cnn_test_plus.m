run ('D:\Program Files - Data Drive\matconvnet-1.0-beta23\matlab\vl_setupnn.m')
imdb=load('SHREC18_extended_30_classes_TestingModels224.mat');
load('sketch_model_withAugmentation\net-epoch-100.mat');

testX = imdb.images.data(:,:,:,:);
testY = imdb.images.label(:,:);
predY = zeros(1,length(testY));

buffer = [];
ptr = 0;
cls = 1;
cnt = 0;
correct = 0;
wrong = 0;
prediction = [];
similarity_list = zeros(0, 6);
distance_matrix = zeros(length(testY), 30);

net.layers(end) = [] ;
for i = 1:length(testY)
    i 
    testimg = testX(:,:,:,i);
    testimg = bsxfun(@minus,testimg,net.meta.normalization.averageImage) ;
    res = vl_simplenn(net, testimg);
    pred = squeeze(gather(res(end).x)) ;
    distance_matrix(i, :) = pred;
    [~,pred] = max(pred);
    predY(i) = pred;
    ptr = ptr + 1;
    buffer(end + 1) = pred;
    if ptr == 13  %13 1  %each model has 13 faces or each sketch has 1 face
        ptr = 0;
        pred_class = mode(buffer);
        prediction(end + 1) = pred_class;
        if pred_class == cls
            correct = correct + 1;
        else
            wrong = wrong + 1;
        end
        cnt = cnt + 1;
        if cnt == 30  %30 300  %each class has 30 models or 300 images, refer to the .cla files
            cls = cls + 1;
            cnt = 0;
        end
        buffer = [];
    end

end

mean(predY==testY)
disp(correct);
disp(correct / size(prediction, 2));
disp(wrong);
disp(wrong / size(prediction, 2));

%save('distance_matrix_images.mat', 'distance_matrix', '-v7.3');
save('distance_matrix_models.mat', 'distance_matrix', '-v7.3');

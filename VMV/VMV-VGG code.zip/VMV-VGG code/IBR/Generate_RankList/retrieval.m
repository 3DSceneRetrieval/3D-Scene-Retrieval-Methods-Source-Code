%sketches=load('distance_matrix_sketches.mat');
sketches=load('distance_matrix_images.mat'); %could be the image for IBR
models=load('distance_matrix_models.mat');

cls=30;%30
sketch_num=9000; %210; %210 total 
model_num=900; %900; %900 total
model_faces=13;%12 faces
buffer=zeros(model_faces, cls, 'single');
pred_class=zeros(1,cls, 'single');
mark=zeros(1,model_num,'single');%judge wether a model is added to the rank_result
res=[];%store the final results

sketches_test=sketches.distance_matrix(1:sketch_num,1:cls);
models_test=models.distance_matrix(1:model_num*model_faces,1:cls);






for i = 1:sketch_num
    i
    [value, rank] = sort(sketches_test(i,:),'descend');
    top=rank(1); %top
    for p=1:cls %store 1st,2nd,3rd... largest # for all models
        for j = 1:model_num
            for k=1:model_faces %12 faces
                [value1,rank1]=sort(models_test((j-1)*model_faces+k,:),'descend');
                for m=1:cls
                    buffer(k,m)=rank1(m);%store 1st,2nd,3rd... largest # for each face
                end   
            end
            for n=1:cls
                    pred_class(n)=mode(buffer(:,n));
            end   
            if pred_class(p)==top && mark(j)~=1
               res(end+1)=j;
               mark(j)=1;
            end
            buffer=zeros(model_faces, cls, 'single');
        end
    end
    for j = 1:model_num
        if mark(j)==0
           res(end+1)=j;  
        end
    end   
    mark=zeros(1,model_num,'single');
    
    path1=strcat('RankValueList/', int2str(i), '.txt');
    path2=strcat('RankValueList/value', int2str(i), '.txt');
    fid1=fopen(path1,'w+');
    fid2=fopen(path2,'w+');
    for k=1:length(res)
       fprintf(fid1,'%d\r\n',res(k));
       fprintf(fid2,'%12.12f\r\n',0.0001*k);
    end
    fclose(fid1);
    fclose(fid2);
    res=[];
end





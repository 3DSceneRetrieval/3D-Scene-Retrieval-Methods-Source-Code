#include<iostream>
#include<cstring>
#include<string>
#include<cstdlib>
#include<vector>
#include<fstream>
#include<ctime>
#include<windows.h>
using namespace std;

#define ImageNum 9000
#define ModelNum 900
struct mapping
{
	int init_value;
	int mapping_value;
};

void ReadMappingTxt(int *arr, int* new_arr)
{
	int i;
	for (i = 0; i < ModelNum; i++)
		arr[i] = i + 1;
	ifstream infile;
	infile.open("D:\\IBR\\900modelsIndexInClaTest.txt");
	int* ptr = &new_arr[0];
	while (!infile.eof())
	{
		infile >> *ptr;
		ptr++;
	}
	infile.close();

}

void ReadInputTxt(int* new_arr, string name)
{
	ifstream infile;
	infile.open(name);
	int* ptr = &new_arr[0];
	while (!infile.eof())
	{
		infile >> *ptr;
		ptr++;
	}
	infile.close();
}

void init_Mapping(int* index21, int* index90, mapping* map)
{
	int i;
	for (i = 0; i < ModelNum; i++)
	{
		map[i].init_value = index21[i];
		map[i].mapping_value= index90[i];
	}
}

void Mapping(int* sorted, int* sortedNew, mapping* map)
{
	int i, j;
	for (i = 0; i < ModelNum; i++)
	{
		for (j = 0; j < ModelNum; j++)
		{
			if (sorted[i] == map[j].init_value)
			{
				sortedNew[i] = map[j].mapping_value;
				break;
			}
		}
	}

}

void OutputMappedFiles(int *arr,string name)
{
	ofstream out(name, ios::app);
	if (out.is_open())
	{
		for (int i = 0; i < ModelNum; i++)
		{
			out << arr[i] <<endl;
		}
		out << endl << endl;
		out.close();
	}
}

int main()
{
	int index21[ModelNum],index90[ModelNum];
	int sorted[ModelNum], sortedNew[ModelNum]; //output the mapped sorted files
	mapping map[ModelNum];

	ReadMappingTxt(index21, index90);
	init_Mapping(index21,index90,map);

	for (int i = 0; i < ImageNum; i++)//testing pictures
	{
		string name1 = "D:\\IBR\\RankValueList\\" + to_string(i+1) + ".txt";
		ReadInputTxt(sorted, name1);

		Mapping(sorted, sortedNew, map);

		string name2 = "D:\\IBR\\RankValueList_mapped\\" + to_string(i+1) + ".txt";
		OutputMappedFiles(sortedNew, name2);
	}
	system("pause");
	return 0;
}
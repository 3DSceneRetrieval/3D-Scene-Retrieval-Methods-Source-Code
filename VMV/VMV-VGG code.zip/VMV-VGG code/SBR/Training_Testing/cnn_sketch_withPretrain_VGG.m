function [net, info] = cnn_sketch_withPretrain_VGG(varargin)

run ('D:\Program Files - Data Drive\matconvnet-1.0-beta23\matlab\vl_setupnn.m');
addpath('D:\Program Files - Data Drive\matconvnet-1.0-beta23\examples');


trainOpts.batchSize = 64;
trainOpts.numEpochs = 100 ;
trainOpts.continue = true ;
trainOpts.gpus = 2  ;
trainOpts.learningRate = 0.00001 ;
trainOpts.expDir = 'sketch_model_withAugmentation/' ;
trainOpts = vl_argparse(trainOpts, varargin);


imdbPath  = fullfile('SHREC18_extended_30_classes_TrainingSketches256.mat');
imdb = load(imdbPath) ;

% Initlialize a new network
net = initializeCNN_VGG() ;

imdb.images.data(:,:,1,:) = imdb.images.data(:,:,1,:) - net.meta.normalization.averageImage(:,:,1) ;
imdb.images.data(:,:,2,:) = imdb.images.data(:,:,2,:) - net.meta.normalization.averageImage(:,:,2) ;
imdb.images.data(:,:,3,:) = imdb.images.data(:,:,3,:) - net.meta.normalization.averageImage(:,:,3) ;

[net,info] = cnn_train(net, imdb, @getBatch, trainOpts) ;

function [im, label] = getBatch(imdb, batch)
im = imdb.images.data(:,:,:,batch) ;
label = imdb.images.label(1,batch) ;

N = length(batch);
WH = 224;
RS = 256-WH+1;
im_new = zeros(WH,WH,size(im,3),N,'single'); 
for i = 1:N
    x = randperm(RS,1);
    y = randperm(RS,1);
   roll = rand(); 
   if roll>0.45 
      tmpImg = imrotate(im(:,:,:,i),randi([-5 5],1,1),'bilinear','crop');
   else
        tmpImg = im(:,:,:,i);
   end
     im_new(:,:,:,i) = tmpImg(x:(x+WH-1),y:(y+WH-1),:);
   roll = rand(); 
   if roll>0.5 
       im_new(:,:,:,i) = fliplr(im_new(:,:,:,i));
   end
end
im = im_new;


kNumClasses = 30;
kNumItems = 540;
kNumFolds = 3;
kNumTrainingItems = ceil(kNumItems * (kNumFolds - 1) / kNumFolds);
kImageWidth = 256;%256 for traning, 224 for testing
kNumChannels = 3; 

sets = {'train', 'val'};
classes = cell(1, kNumClasses);


for i = 1:kNumClasses
    classes{i} = i;
end

meta = struct();
meta.classes = classes;
meta.sets = sets;



label = ones(1, kNumClasses * kNumItems, 'single');
for i = 1:kNumClasses
    for j = 1:kNumItems
        label((i - 1) * kNumItems + j) = i;
    end
end

set = ones(1, kNumClasses * kNumItems, 'double');
for i = 1:kNumClasses
    for j = 1:kNumTrainingItems
        set((i - 1) * kNumItems + j) = 1;
    end
    for j = kNumTrainingItems + 1:kNumItems
        set((i - 1) * kNumItems + j) = 2;
    end
end

data = ones(kImageWidth, kImageWidth, kNumChannels, kNumClasses * kNumItems, 'single');
id=zeros(1,kNumClasses * kNumItems);
for i=1:kNumClasses * kNumItems
    id(i)=i;
end

for i = 1:kNumClasses
    i
    for j = 1:kNumItems
        idx = (i - 1) * kNumItems + j;
        image_path = strcat('E:\tranining224\', int2str(idx), '.png');
        I = imread(image_path);
        [~, ~, dim] = size(I);

        if dim == 1
             I = cat(3, I, I, I);
        end
        data(:, :, :, idx) = I;
    end
end

images = struct();
images.id=id;
images.data = data;
images.label = label;
images.set = set;

save('SHREC18_extended_30_classes_TrainingSketches256.mat', 'images',  'meta', '-v7.3');
%save('SHREC18_extended_30_classes_TestingModels224.mat', 'images',  'meta', '-v7.3');



import os
import os.path as osp
import numpy as np


class DataLoader(object):
    def __init__(self, batch_size, data_train_path, data_test_path):
        xtrain_path, ytrain_path = data_train_path
        xtest_path, ytest_path = data_test_path
        self.xtrain = np.load(xtrain_path)
        self.ytrain = np.load(ytrain_path)
        self.xtest = np.load(xtest_path)
        self.ytest = np.load(ytest_path)

        num_cls = int(max(self.ytrain) + 1)
        self.ytrain = self.__to_one_hot(self.ytrain, num_cls)
        self.ytest = self.__to_one_hot(self.ytest, num_cls)

        self.cnt_train = self.xtrain.shape[0]
        self.cnt_test = self.xtest.shape[0]
        self.batch_size = min(batch_size, self.cnt_train)
        self.permutation = np.random.permutation(self.cnt_train)
        
        self.pt_train_idx = 0
        self.pt_test_idx = 0

    
    def __to_one_hot(self, y, num_cls):
        _y = np.zeros(shape=(len(y), num_cls))
        for i in range(len(y)):
            _y[i][int(y[i])] = 1
        return _y


    def next_batch(self):
        current_pt = self.pt_train_idx
        self.pt_train_idx = min(self.batch_size + current_pt, self.cnt_train)
        x = self.xtrain[current_pt:self.pt_train_idx]
        y = self.ytrain[current_pt:self.pt_train_idx]
        if self.pt_train_idx == self.cnt_train:
            self.pt_train_idx = 0
            self.permutation = np.random.permutation(self.cnt_train)
        return x, y


    def next_test(self):
        current_pt = self.pt_test_idx
        self.pt_test_idx = min(self.batch_size + current_pt, self.cnt_test)
        x = self.xtest[current_pt:self.pt_test_idx]
        y = self.ytest[current_pt:self.pt_test_idx]
        if self.pt_test_idx == self.cnt_test:
            self.pt_test_idx = 0
        return x, y

import os
import os.path as osp
import subprocess


def create_folder(fold_path):
    if not osp.exists(fold_path):
        os.makedirs(fold_path)


if __name__ == '__main__':
    cls_fp = osp.join(os.getcwd(), '..', 'data', 'classes.txt')
    classes = [cls.rstrip() for cls in open(cls_fp, 'r').readlines()]
    training_image_fp = osp.join(os.getcwd(), '..', 'image', '2D_Sketches_Training')
    gt_fp = osp.join(os.getcwd(), '..', 'data', 'SceneSBR_Sketch_Training.cla')
    result_fp = osp.join(os.getcwd(), '..', 'image', 'training')
    data = open(gt_fp, 'r').readlines()[3:]
    i = 0
    while i < len(data):
        print(data[i])
        cls, _, n = data[i].split()
        cls_fp = osp.join(result_fp, cls)
        create_folder(cls_fp)
        for j in range(int(n)):
            image_fn = data[i+j+1].rstrip() + '.png'
            image_fp = osp.join(training_image_fp, image_fn)
            cmd = 'cp {} {}'.format(image_fp, cls_fp)
            print(cmd)
            subprocess.call(cmd, shell=True)
        i += int(n) + 3

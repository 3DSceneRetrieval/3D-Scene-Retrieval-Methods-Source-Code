import os
import os.path as osp
import pandas as pd
import numpy as np
from pandas import DataFrame
import subprocess


def load_result(result_filepath):
    res = pd.read_csv(result_filepath)
    list_predicted = []
    for v in res.values:
        id = v[1]
        top1 = int(v[2])
        list_predicted.append((id, top1))
    return list_predicted


def compare_to_gt(result_filepath, gt_filepath):
    list_predicted = load_result(result_filepath)
    gts = np.load(gt_filepath)
    diff = []
    for i in range(len(list_predicted)):
        id, top1 = list_predicted[i]
        if top1 != int(gts[i]):
            diff.append((id, top1, int(gts[i])))
    return diff


def dump_csv(data, csv_filepath, classes):
    num_data = len(data)
    print('Diff: {} files'.format(num_data))
    ids = []
    top1s = []
    gts = []
    for i in range(num_data):
        id, top1, gt = data[i]
        ids.append(id)
        top1s.append(classes[top1])
        gts.append(classes[gt])
    d = {
        'id': ids,
        'predicted': top1s,
        'ground_truth': gts
    }
    cols = ['id', 'predicted', 'ground_truth']
    df = DataFrame(d, columns=cols)
    df.to_csv(csv_filepath)


def list_diff_image(diff, diff_fp, test_image_fp, classes):
    num_diff = len(diff)
    for i in range(num_diff):
        id, top1, _ = diff[i]
        category_fp = osp.join(diff_fp, classes[top1])
        create_folder(category_fp)
        image_fp = osp.join(test_image_fp, id)
        cmd = 'cp {} {}'.format(image_fp, category_fp)
        print(cmd)
        subprocess.call(cmd, shell=True)


def create_folder(fold_path):
    if not osp.exists(fold_path):
        os.makedirs(fold_path)


if __name__ == '__main__':
    result_filepath = osp.join(os.getcwd(), '..', 'data', 'results', 'predicted.csv')
    gt_filepath = osp.join(os.getcwd(), '..', 'data', 'combined_raw', 'testset_y.npy')
    test_image_fp = osp.join(os.getcwd(), '..', 'image', '2D_Sketches_Testing')
    diff_fp = osp.join(os.getcwd(), '..', 'data', 'results', 'diff')
    create_folder(diff_fp)
    classes_fp = osp.join(os.getcwd(), '..', 'data', 'classes.txt')
    classes = [cls.rstrip() for cls in open(classes_fp, 'r').readlines()]
    csv_filepath = osp.join(os.getcwd(), '..', 'data', 'results', 'compared.csv')
    diff = compare_to_gt(result_filepath, gt_filepath)
    list_diff_image(diff, diff_fp, test_image_fp, classes)
    dump_csv(diff, csv_filepath, classes)

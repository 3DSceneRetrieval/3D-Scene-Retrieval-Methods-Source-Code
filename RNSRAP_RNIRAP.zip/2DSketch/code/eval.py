import torch
from data_loader import *
from fcnet import *
from tqdm import tqdm
#from combine_data import *
import os
import os.path as osp
import argparse
import pandas as pd
from pandas import DataFrame


def create_argparse():
    parser = argparse.ArgumentParser()
    parser.add_argument('checkpoint_filepath', help='Path of checkpoint file')
    parser.add_argument('result_filename', help='Where to save the csv result')
    return parser


#def combine_features(data_path, combine_path, in_dim=2048):
#    combined_filename = 'x_attributes.npy'
#    combine_path = osp.join(combine_path, combined_filename)
#    if osp.isfile(combine_path):
#        print("All features are already combined")
#        return
#
#    features_filenames = sorted(os.listdir(data_path))
#    num_data = len(features_filenames)
#    x = np.empty((num_data, in_dim), dtype=np.float)
#    print("Combining features...")
#    for i, f in enumerate(features_filenames):
#        data_filepath = osp.join(data_path, f)
#        data = np.load(data_filepath)
#        x[i] = data
#    np.save(combine_path, x)


def load_network(checkpoint_dir, filename):
    checkpoint = load_checkpoint(checkpoint_dir, filename)
    N = checkpoint['Net']
    return N


def eval(N, top, data_train_path, data_test_path):
    data = DataLoader(N.batch_size, data_train_path, data_test_path)
    cnt = 0
    results = []
    device = 'cpu'
    if torch.cuda.is_available():
        device = 'cuda'
    while cnt < data.cnt_test:
        x, _ = data.next_test()
        cnt += x.shape[0]
        x = torch.Tensor(x).to(device)
        out = N(x)
        _, predicts = out.sort(1)
        predicts = predicts[:,-top:].cpu().numpy().tolist()
        results += predicts
    return results


def dump_csv(results, top, data_path, result_filepath):
    list_imgs = [id.rstrip() for id in open(data_path, 'r').readlines()]
    num_imgs = len(list_imgs)
    ids = []
    predicted = []
    cols = ['ids']
    for i in range(top):
        cols.append('#{}'.format(i+1))
        predicted.append([])
    for i in range(num_imgs):
        out = results[i]
        img_name = list_imgs[i] + '.png'
        for j in range(len(out)):
            predicted[j].append(out[j])
        ids.append(img_name)
    d = {'ids': ids}
    for i in range(top):
        d.update({'#{}'.format(i+1): predicted[i]})
    df = DataFrame(d, columns=cols)
    df.to_csv(result_filepath)


def create_folder(fold_path):
    if not osp.exists(fold_path):
       os.makedirs(fold_path)


if __name__ == '__main__':
    args = create_argparse().parse_args()
    in_dim = 2048

    data_path = osp.join(os.getcwd(), '..', 'data', 'combined_raw', 'SceneSBR_Sketch_Testing_List.txt')
    combine_path = osp.join(os.getcwd(), '..', 'data', 'combined_raw')
    data_train_path = (osp.join(combine_path, 'trainset_x_augmented.npy'), osp.join(combine_path, 'trainset_y_augmented.npy'))
    data_test_path = (osp.join(combine_path, 'testset_x.npy'), osp.join(combine_path, 'testset_y.npy'))
#    create_folder(combine_path)
#    combine_features(data_path, combine_path, in_dim=in_dim)
    
    checkpoint_dir = osp.join(os.getcwd(), '..', 'data', 'checkpoint')
    checkpoint_filename = args.checkpoint_filepath
    N = load_network(checkpoint_dir, checkpoint_filename)

    results = eval(N, 1, data_train_path, data_test_path)
    result_filepath = osp.join(os.getcwd(), '..', 'data', 'results')
    create_folder(result_filepath)
    result_filename = args.result_filename
    dump_csv(results, 1, data_path, osp.join(result_filepath, result_filename))

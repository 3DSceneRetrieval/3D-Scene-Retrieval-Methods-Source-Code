# Place Adaptation
Pretrained Alexnet: http://places2.csail.mit.edu/models_places365/whole_alexnet_places365_python36.pth.tar

Pretrained Resnet18: http://places2.csail.mit.edu/models_places365/whole_wideresnet18_places365_python36.pth.tar

python run_placesCNN_unified.py  attribute_folder category_folder --attribute-folder-log attribute_logs --category-folder-log category_logs
p

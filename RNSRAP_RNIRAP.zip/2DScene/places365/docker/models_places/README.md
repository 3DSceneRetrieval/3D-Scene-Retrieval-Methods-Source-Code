Placeholder file to hold models_places dir and make the Dockerfile work correctly.

# This is to classify 3D screenshot base on extracted Restnet50 & Place365 feature

# Prepare dataset:
Each 3D model is capture by a screenshot image. then:
Use *.py in "extract_feats" folder to extract R50 & Place365 Feature
for each trainset & testset. It may requires labels to create
y_train y_test.npy. Labels for y_test.py can create as place holder of zeroes or -1. PCA were perform by PCA in scikit-learn to reduce dim of data to 512. 
-> https://scikit-learn.org/stable/modules/generated/sklearn.decomposition.PCA.html

# Prepare config file to train/test:
Some examples are in configs

#To train: train.py

#To inference on test dataset: test.py. 
From test.py, one can save score of classes to fusion & voting scheme. We use multiple models (changing activation functions, dimension of inputdata, load pretrained weight from places 365, fuse feature from places 365) to output class scores, than voting to produce the final prediction

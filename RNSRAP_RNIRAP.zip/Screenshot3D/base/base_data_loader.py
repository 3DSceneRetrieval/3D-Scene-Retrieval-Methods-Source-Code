import numpy as np
from torch.utils.data import DataLoader
from torch.utils.data.dataloader import default_collate
from torch.utils.data.sampler import SubsetRandomSampler
from torch.utils.data.dataset import Subset


class BaseDataLoader(DataLoader):
    """
    Base class for all data loaders
    """
    def __init__(self, dataset, batch_size, shuffle, validation_split, num_workers, collate_fn=default_collate):
        self.validation_split = validation_split
        self.shuffle = shuffle
        self.original_dataset = dataset        
        self.batch_size = batch_size
        n_samples = len(self.original_dataset)
        self.num_workers = num_workers

        idx_full = np.arange(n_samples)
        np.random.seed(0) 
        np.random.shuffle(idx_full)

        len_valid = int(n_samples * validation_split)

        self.valid_idx = idx_full[0:len_valid]
        self.train_idx = np.delete(idx_full, np.arange(0, len_valid))

        train_set = Subset(self.original_dataset, self.train_idx)

        super(BaseDataLoader,self).__init__(train_set, batch_size, shuffle, num_workers=num_workers, collate_fn=collate_fn) 
        
    def split_validation(self):
        if len(self.valid_idx)==0:
            return None
        else:
            return DataLoader(Subset(self.original_dataset, self.valid_idx), self.batch_size,shuffle=False, num_workers=self.num_workers)
    

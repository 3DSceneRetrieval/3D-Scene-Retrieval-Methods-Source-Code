from torchvision import datasets, transforms
from base import BaseDataLoader
from torch.utils.data import Dataset, DataLoader
from skimage import io
import os
import numpy as np
from PIL import Image

class ImageListDataset(Dataset):
    def __init__(self, data_dir, image_list,transform=None,have_label=True):
        self.data_dir = data_dir
        self.image_list_path = image_list
        self.transform = transform

        list_samples = [ u.strip() for u in open(self.image_list_path)]
        if have_label:
            self.list_samples = [ (u.split()[0], u.split()[1] ) for u in list_samples]
        else:
            self.list_samples = [ (u.split()[0], -1)for u in list_samples]

    def __len__(self):
        return len(self.list_samples) 

    def __getitem__(self, idx):
        img_name =self.list_samples[idx][0]
        img_path = os.path.join(self.data_dir, img_name)

        sample = Image.open(img_path)
        sample = sample.convert("RGB")

        #print(np.array(sample).shape)
        if self.transform:
            sample = self.transform(sample)

        return sample, np.float(self.list_samples[idx][1])
      

class ImageListDataLoader(BaseDataLoader):
    """
    MNIST data loading demo using BaseDataLoader
    """
    def __init__(self, data_dir, image_list_path, batch_size, shuffle, validation_split, num_workers, training=True):
        data_transforms = {
            'train': transforms.Compose([
                transforms.RandomResizedCrop(224),
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
            ]),
            'val': transforms.Compose([
                transforms.Resize(256),
                transforms.CenterCrop(224),
                transforms.ToTensor(),
                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
            ]),
        } 
        if training:
            transfomation = data_transforms['train']
        else:
            transfomation = data_transforms['val']
        self.dataset = ImageListDataset(data_dir, image_list_path,transform=transfomation,have_label=training)
        super(ImageListDataLoader, self).__init__(self.dataset, batch_size, shuffle, validation_split, num_workers)
        

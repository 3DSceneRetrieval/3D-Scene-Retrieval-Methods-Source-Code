import torch
import torch.nn as nn
import torchvision.models as models
import torchvision.transforms as transforms
from torch.autograd import Variable
from PIL import Image
import torch.utils.data as data
import pandas as pd
import os
from skimage import io
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, utils
import numpy as np
import argparse
import sys
import tqdm
import ipdb
from run_placesCNN_unified import load_model, returnTF

class ImageDatasetFromList(data.Dataset):
  """My Image dataset."""
  
  def __init__(self, list_file, transform=None):
      """
      Args:
          csv_file (string): Path to the csv file with annotations.
          root_dir (string): Directory with all the images.
          transform (callable, optional): Optional transform to be applied
              on a sample.
      """
      self.list_file = list_file
      self.transform = transform

  def __len__(self):
      return len(self.list_file)

  def __getitem__(self, idx):
      img_name =self.list_file[idx]
      sample = Image.open(img_name)
      sample = sample.convert('RGB')
      
      if self.transform:
          sample = self.transform(sample)

      return sample, -1 # -1 is place holder for none class


def extract(model, data_loader, device):
    
    model = model.to(device)
    model.eval()

    result_x = np.zeros( (len(data_loader.dataset) , 365))
    result_target = np.zeros( (len(data_loader.dataset),1 ))

    t = 0
    with torch.no_grad():
        for batch_idx, (x, target) in enumerate(tqdm.tqdm(data_loader)):
            x = x.to(device)
            target = target.to(device)
            out = model(x)
            out = out.cpu().data.numpy()
            out = np.squeeze(out)
            target = target.cpu()
            result_x[t: t + out.shape[0], :] = out
            result_target[t: t+out.shape[0], :] = target.reshape(-1,1)
            t = t + out.shape[0] 
            #print out.shape
            
    return result_x, result_target


def extract_feature_from_list_imgs(list_imgs):
    normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                     std=[0.229, 0.224, 0.225])
    transfomation = transforms.Compose([
                transforms.Resize((224,224)),
                transforms.ToTensor(),
                normalize,
            ])
    tf = returnTF()
    trainset = ImageDatasetFromList(list_imgs, tf)

    dataloader = torch.utils.data.DataLoader(trainset,
                                             batch_size=256, shuffle=False,
                                             num_workers=12)
    
    model = load_model()
    # get the softmax weight
    params = list(model.parameters())
    weight_softmax = params[-2].data.numpy()
    weight_softmax[weight_softmax<0] = 0

    model.eval()

    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    x,_ = extract(model, dataloader, device)
    return x

if __name__=='__main__':
    print(sys.argv)
    list_images_label = open(sys.argv[2]).readlines()
    list_imgs = [u.strip().split()[0] for u in list_images_label]
    list_imgs = [os.path.join(sys.argv[1], u) for u in list_imgs]
    list_label = [int(u.strip().split()[1]) for u in list_images_label]
    i=0
    while i < len(list_imgs):
        ite = list_imgs[i]
        if not os.path.exists(ite):
            #ipdb.set_trace()
            print('object {} not exists'.format(ite))
            del list_imgs[i:i+26] 
            del list_label[i:i+26]
        i+=1
    x = extract_feature_from_list_imgs(list_imgs)
    y = np.array(list_label)

    np.save('x_place_att'+sys.argv[3]+'.npy',x)
    np.save('y_place_att'+sys.argv[3]+'.npy',y)



'''
normalize = transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                     std=[0.229, 0.224, 0.225])
transfomation = transforms.Compose([
            transforms.ToPILImage(),
            #transforms.Resize((224,224)),
            transforms.ToTensor(),
            normalize,
        ])
trainset = ImageDataset('/home/minhb/ModelNet40/data/ModelNet40/modelnet40_test_list_label_26.csv', '/home/minhb/ModelNet40/data/ModelNet40/render_modelnet40_26/', transfomation)

trainset_loader = torch.utils.data.DataLoader(trainset,
                                             batch_size=17, shuffle=False,
                                             num_workers=2)

resnet = resnet.cuda()

len(trainset_loader.dataset)

x,y = extract(resnet, trainset_loader)

np.save('x_test',x)
np.save('y_test',y)
'''
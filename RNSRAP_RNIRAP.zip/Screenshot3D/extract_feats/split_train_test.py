import numpy as np
import ipdb

TRAINING_LABEL_FILE_PATH ='../data/SceneIBR_Model_Training.cla'
f = open(TRAINING_LABEL_FILE_PATH,'r')
f.readline()
n_classes, n_samples = [int(u) for u in f.readline().strip().split()]
f.readline()
count_samples = 0
class_id=0
label_dict = {}
while count_samples < n_samples:
    line = f.readline().strip().split()
    class_text, _, num_models_in_class = line[0], int(line[1]), int(line[2]) 
    for i in range(num_models_in_class):
        id = int(f.readline().strip())
        label_dict[id] = [class_id, class_text]
        count_samples += 1
        print(id,class_id,class_text)
    f.readline()
    f.readline()
    class_id+=1
f.close()    
#ipdb.set_trace()
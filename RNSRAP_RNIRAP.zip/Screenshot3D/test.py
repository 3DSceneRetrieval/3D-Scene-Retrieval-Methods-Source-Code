import os
import argparse
import torch
from tqdm import tqdm
import data_loader.data_loaders as module_data
import model.loss as module_loss
import model.metric as module_metric
import model.model as module_arch
from train import get_instance
import numpy as np
import torch.utils.data as utils
import ipdb

def sigmoid(x):
  return 1 / (1 + math.exp(-x))
def main(config, resume):
    # setup data_loader instances
    x_test = torch.Tensor(np.load(config['data']['x_test_path']))
    y_test = torch.Tensor(np.load(config['data']['y_test_path'])).long()
    ipdb.set_trace()
    dataset_test = utils.TensorDataset(x_test,y_test)
    dataloader_test = utils.DataLoader(dataset_test, batch_size=128, shuffle=False, num_workers=6)
    # build model architecture

    model = get_instance(module_arch, 'arch', config)
    model.summary()

    # get function handles of loss and metrics
    loss_fn = getattr(module_loss, config['loss'])
    metric_fns = [getattr(module_metric, met) for met in config['metrics']]

    # load state dict
    dir_num = resume.split('/')[-2]
    checkpoint = torch.load(resume)
    state_dict = checkpoint['state_dict']
    #if config['n_gpu'] > 1:
    #    model = torch.nn.DataParallel(model)
    #import ipdb; ipdb.set_trace()
    model.load_state_dict(state_dict)
    model_epoch = checkpoint['epoch']
    #prepare model for testing
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = model.to(device)
    model.eval()


    preds = []
    scores = None
    with torch.no_grad():
        for i, (data, target) in enumerate(tqdm(dataloader_test)):
            data, target = data.to(device), target.to(device)
            output = model(data)
            output = torch.nn.functional.softmax(output).cpu()
            batch_size = data.shape[0]
            pred = torch.argmax(output, dim=1)

            preds = preds + pred.tolist()
            if scores is None:
                scores = output
            else:
                scores = np.vstack((scores,output))
        #np.savetxt('test_scores_{}_{}_{}.txt'.format(config['name'],dir_num,model_epoch),scores, fmt='%.4f')
        #np.savetxt('test_predict_{}_{}_{}.txt'.format(config['name'],dir_num,model_epoch), np.array(preds), fmt='%d')
        np.savetxt('test_predict.txt', np.array(preds), fmt='%d')
    

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='PyTorch Template')

    parser.add_argument('-r', '--resume', default=None, type=str,
                           help='path to latest checkpoint (default: None)')
    parser.add_argument('-d', '--device', default=None, type=str,
                           help='indices of GPUs to enable (default: all)')

    args = parser.parse_args()

    if args.resume:
        config = torch.load(args.resume)['config']
        #config['data']['x_test_path'] = '/home/lab/projects/shrec19_SBR_IBR/data/3D_Model_R50_extracted/x_placetest.npy'
        #config['data']['y_test_path'] = '/home/lab/projects/shrec19_SBR_IBR/data/3D_Model_R50_extracted/y_placetest.npy'
        #ipdb.set_trace()
        #config['data']['x_test_path'] = '/home/lab/projects/shrec19_SBR_IBR/data/3D_Model_R50_extracted/x_test.npy'
        #config['data']['y_test_path'] = '/home/lab/projects/shrec19_SBR_IBR/data/3D_Model_R50_extracted/y_test.npy'
        #config['data']['x_test_path'] = '/home/lab/projects/shrec19_SBR_IBR/data/3D_Model_R50_extracted/x_test_rn_365_reduced.npy'
        #config['data']['y_test_path'] = '/home/lab/projects/shrec19_SBR_IBR/data/3D_Model_R50_extracted/y_test.npy'

    if args.device:
        os.environ["CUDA_VISIBLE_DEVICES"]=args.device

    main(config, args.resume)

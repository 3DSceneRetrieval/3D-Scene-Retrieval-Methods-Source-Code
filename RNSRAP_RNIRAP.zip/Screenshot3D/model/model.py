import torch.nn as nn
import torch.nn.functional as F
from base import BaseModel
import torch
import torchvision

class BaselineModel(BaseModel):
    def __init__(self, num_classes=21):
        super(BaselineModel, self).__init__()
        self.fc1 = nn.Linear(2048, 64)
        self.fc2 = nn.Linear(64, num_classes)
        self.relu = nn.ReLU()
    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        return x

class BaselineModelSigmoid(BaseModel):
    def __init__(self, num_classes=21, hidden_size = 64,activation="sigmoid", **kagrs):
        super(BaselineModelSigmoid, self).__init__()
        self.fc1 = nn.Linear(2048, hidden_size)
        self.fc2 = nn.Linear(hidden_size, num_classes)
        import ipdb; ipdb.set_trace()
        if activation is "sigmoid":
            self.act = nn.Sigmoid()
        elif activation is "relu":
            self.act = nn.ReLU()
        

        if 'pretrained_path' in kagrs.keys():
            pretrained = torch.load(kagrs['pretrained_path'])['state_dict']
            self.fc1.weight.data = pretrained['fc.0.weight']
            self.fc2.weight.data = pretrained['fc.2.weight']
            self.fc1.bias.data = pretrained['fc.0.bias']
            self.fc2.bias.data = pretrained['fc.2.bias']


    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.fc2(x)
            
        return x

class OnlyFC(BaseModel):
    def __init__(self, num_classes=21, **kagrs):
        super(OnlyFC, self).__init__()
        self.fc = nn.Linear(2048, num_classes)
        # init from pretrained
        pretrained = torch.load(kagrs['pretrained_path'])['state_dict']
        self.fc.weight.data = pretrained['fc.weight']
        self.fc.bias.data = pretrained['fc.bias']

    def forward(self, x):
        x = self.fc(x)
        return x


class BaselineModelSigmoidWithAttribute(BaseModel):
    def __init__(self, num_classes=21, hidden_size = 64,activation="sigmoid", input_d = 2048+365,**kagrs):
        super(BaselineModelSigmoidWithAttribute, self).__init__()
        self.fc1 = nn.Linear(input_d, hidden_size)
        self.fc2 = nn.Linear(hidden_size, num_classes)
        if activation == "sigmoid":
            self.act = nn.Sigmoid()
        elif activation == "relu":
            self.act = nn.Tanh()

        if 'pretrained_path' in kagrs.keys():
            pretrained = torch.load(kagrs['pretrained_path'])['state_dict']
            self.fc1.weight.data = pretrained['fc.0.weight']
            self.fc2.weight.data = pretrained['fc.2.weight']
            self.fc1.bias.data = pretrained['fc.0.bias']
            self.fc2.bias.data = pretrained['fc.2.bias']


    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.fc2(x)
            
        return x
import os
import json
import argparse
import torch
import data_loader.data_loaders as module_data
import model.loss as module_loss
import model.metric as module_metric
import torch.nn as nn
import model.model as module_arch
import numpy as np
import torch.utils.data as utils
from trainer import Trainer
from utils import Logger
import torchvision.models as models
from torchvision import datasets, transforms

def get_instance(module, name, config, *args):
    if config[name]['type'] is None:
        return None
    return getattr(module, config[name]['type'])(*args, **config[name]['args'])
def get_tf(is_training):
    data_transforms = {
        'train': transforms.Compose([
            transforms.RandomResizedCrop(224),
            transforms.RandomHorizontalFlip(),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ]),
        'val': transforms.Compose([
            transforms.Resize(256),
            transforms.CenterCrop(224),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ]),
    }
    if is_training:
        return data_transforms['train']
    else:
        return data_transforms['val']




def main(config, resume):
    train_logger = Logger()
    dataset_train = datasets.ImageFolder('/home/lab/projects/shrec19_SBR_IBR/data/Place_Needed_concept_1k/', get_tf(True))

    #x_train = torch.Tensor(np.load(config['data']['x_train_path']))
    #x_test = torch.Tensor(np.load(config['data']['x_test_path']))
    #y_train = torch.Tensor(np.load(config['data']['y_train_path'])).long()
    #y_test = torch.Tensor(np.load(config['data']['y_test_path'])).long()

    #dataset_train = utils.TensorDataset(x_train,y_train)
    #dataset_test = utils.TensorDataset(x_test,y_test)
    train_size = int(0.9 * len(dataset_train))
    val_size = len(dataset_train) - train_size
    dataset_train, dataset_val = utils.random_split(dataset_train, lengths=[train_size, val_size])

    dataloader_train = utils.DataLoader(dataset_train, batch_size=64, shuffle=True, num_workers=6)
    dataloader_val = utils.DataLoader(dataset_val, batch_size=128, shuffle=False, num_workers=6)
    #dataloader_test = utils.DataLoader(dataset_test, batch_size=64, shuffle=False, num_workers=6)
 
    # build model architecture
    arch = 'resnet50'
    # load the pre-trained weights
    model_file = '%s_places365.pth.tar' % arch
    model = models.__dict__[arch](num_classes=365)
    checkpoint = torch.load(model_file, map_location=lambda storage, loc: storage)
    state_dict = {str.replace(k,'module.',''): v for k,v in checkpoint['state_dict'].items()}
    model.load_state_dict(state_dict)
    for param in model.parameters():
        param.requires_grad = False 
    num_ftrs = model.fc.in_features
    model.fc = nn.Sequential(
        nn.Linear(num_ftrs, 64),
        nn.Sigmoid(),
        nn.Linear(64,int(config['arch']['args']['num_classes']))
    )

    import ipdb; ipdb.set_trace()
    # get function handles of loss and metrics
    loss = getattr(module_loss, config['loss'])
    metrics = [getattr(module_metric, met) for met in config['metrics']]

    # build optimizer, learning rate scheduler. delete every lines containing lr_scheduler for disabling scheduler
    trainable_params = filter(lambda p: p.requires_grad, model.parameters())
    optimizer = get_instance(torch.optim, 'optimizer', config, trainable_params)
    lr_scheduler = get_instance(torch.optim.lr_scheduler, 'lr_scheduler', config, optimizer)

    trainer = Trainer(model, loss, metrics, optimizer, 
                      resume=resume,
                      config=config,
                      data_loader=dataloader_train,
                      valid_data_loader=dataloader_val,
                      lr_scheduler=lr_scheduler,
                      train_logger=train_logger)

    trainer.train()

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='PyTorch Template')
    parser.add_argument('-c', '--config', default=None, type=str,
                           help='config file path (default: None)')
    parser.add_argument('-r', '--resume', default=None, type=str,
                           help='path to latest checkpoint (default: None)')
    parser.add_argument('-d', '--device', default=None, type=str,
                           help='indices of GPUs to enable (default: all)')
    args = parser.parse_args()

    if args.config:
        # load config file
        config = json.load(open(args.config))
        path = os.path.join(config['trainer']['save_dir'], config['name'])
    elif args.resume:
        # load config file from checkpoint, in case new config file is not given.
        # Use '--config' and '--resume' arguments together to load trained model and train more with changed config.
        config = torch.load(args.resume)['config']
    else:
        raise AssertionError("Configuration file need to be specified. Add '-c config.json', for example.")
    
    if args.device:
        os.environ["CUDA_VISIBLE_DEVICES"] = args.device

    main(config, args.resume)
